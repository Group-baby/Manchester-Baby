//
// Created by Windows11 on 24-11-17.
//

#ifndef INPUTOUTPUT_H
#define INPUTOUTPUT_H



class InputOutput {

};



#endif //INPUTOUTPUT_H
