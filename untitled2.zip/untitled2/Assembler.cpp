//
// Created by Windows11 on 24-11-17.
//

#include "Assembler.h"
#include <fstream>
#include <iostream>
#include <stdexcept>

OpCode Assembler::getOpCode(const string &instruction) {
    switch (instruction){
        case "VAR": return VAR;
        case "JMP": return JMP;
        case "JRP": return JRP;
        case "LDN": return LDN;
        case "STO": return STO;
        case "SUB": return SUB;
        case "CMP": return CMP;
        case "STP": return STP;
        case "LDP": return LDP;
        case "ADD": return ADD;
        case "DIV": return DIV;
        case "MOD": return MOD;
        case "LAN": return LAN;
        case "LOR": return LOR;
        case "LNT": return LNT;
        case "SHL": return SHL;
        case "SHR": return SHR;
        default:
            throw invalid_argument("Invalid opcode: " + instruction);
    }
}

AddressingMode Assembler::getAddressingMode(const string &instruction) {
    switch (instruction) {
        case "INDIRECT": return INDIRECT;
        case "DIRECT": return DIRECT;
        default:
            throw invalid_argument("Invalid opcode: " + instruction);
    }
}

vector<string> Assembler::ScanFile() {
    ifstream inputFile("example.txt");
    vector<string> lines;

    if (!inputFile.is_open()) {
        cerr << "Error opening file!" << endl;
        return lines;
    }

    string line;
    while (getline(inputFile, line)) {
        lines.push_back(line);
    }

    return lines;
}

string Assembler::processAssembleCode(string &target) {
    vector<string>components=splitString(target);
    int n=components.size();

    for (int i = 0; i < n; i++) {
        if(components[i]=="START:"||components[i]=="END:") {
        }
    }
}


vector<string> Assembler::assemble(vector<string> &source) {
    target_instruction=ScanFile();
    int num=target_instruction.size();

    for (int i=0; i<num; i++) {

    }
}

vector<string> splitString(const string &str, char delimiter = ' ') {
    vector<string> ans;
    size_t start = 0;
    size_t end = 0;

    while ((end = str.find(delimiter, start)) != string::npos) {
        ans.push_back(str.substr(start, end - start));
        start = end + 1;
    }

    ans.push_back(str.substr(start));

    return ans;
}