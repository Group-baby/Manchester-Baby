//
// Created by Windows11 on 24-11-17.
//

#include "InputOutput.h"

#include <iostream>

string InputOutput::Input() {
    string input;
    cout << "Please enter a string: ";
    cin >> input;
    return input;
}

void InputOutput::Output(string Content) {
    cout<<Content<<endl;
}