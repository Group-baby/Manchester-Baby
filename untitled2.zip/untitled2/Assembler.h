//
// Created by Windows11 on 24-11-17.
//

#ifndef ASSEMBLER_H
#define ASSEMBLER_H
#include <string>
#include <fstream>
#include <unordered_map>
#include <vector>
using namespace std;
enum OpCode {
    VAR = 0,
    JMP = 1,
    JRP = 2,
    LDN = 3,
    STO = 4,
    SUB = 5,
    CMP = 6,
    STP = 7,
    LDP = 8,
    ADD = 9,
    DIV = 10,
    MOD = 11,
    LAN = 12,
    LOR = 13,
    LNT = 14,
    SHL = 15,
    SHR = 16
};
enum AddressingMode {
    DIRECT = 0,
    INDIRECT = 1
};


class Assembler {
public:
    Assembler();

    ~Assembler();

    vector<string> assemble(vector<string>&source);

private:
    string translateInstruction(const std::string& instruction, int address);

    OpCode getOpCode(const string& instruction);

    unordered_map<string, int> symbolTable;

    vector<string> splitString(const string &str, char delimiter = ' ');

    AddressingMode getAddressingMode(const string &instruction);

    vector<string> ScanFile();

    vector<string> target_instruction;

    string processAssembleCode(string &target);

    int start_in;

    int end_in;
};



#endif //ASSEMBLER_H
