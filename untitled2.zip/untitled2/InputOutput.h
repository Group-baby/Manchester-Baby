//
// Created by Windows11 on 24-11-17.
//

#ifndef INPUTOUTPUT_H
#define INPUTOUTPUT_H
#include <string>
using namespace std;
class InputOutput {
    public:
    string Input();
    void Output(string Content);
};



#endif //INPUTOUTPUT_H
